// app/sites/create/page.tsx
import RegisterForm from './RegisterForm';

export default function RegisterSitePage() {
  return <RegisterForm />;
}